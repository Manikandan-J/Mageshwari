export class Course {
    skillId: String
    skillName: String;
    skillAmount: String;
   

    constructor(skillId,skillName,skillAmount) {
     

        this.skillId = skillId;
        this.skillName = skillName;
        this.skillAmount  = skillAmount;
       
    }
   
 }