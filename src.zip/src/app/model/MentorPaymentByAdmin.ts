export class MentorPaymentByAdmin {
    
    id: number;
    email: String;
    courseName: String; 
    slot1: String;
    slot2: String;
    slot3: String;
    slot4: String;
    totalFee: String;

 }