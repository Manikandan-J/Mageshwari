import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-successful-registration',
  templateUrl: './successful-registration.component.html',
  styleUrls: ['./successful-registration.component.css']
})
export class SuccessfulRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
